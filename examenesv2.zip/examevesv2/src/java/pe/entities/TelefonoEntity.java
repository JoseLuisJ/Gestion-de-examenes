/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "telefonos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TelefonoEntity.findAll", query = "SELECT t FROM TelefonoEntity t"),
    @NamedQuery(name = "TelefonoEntity.findByIdtelefono", query = "SELECT t FROM TelefonoEntity t WHERE t.idtelefono = :idtelefono"),
    @NamedQuery(name = "TelefonoEntity.findByNumero", query = "SELECT t FROM TelefonoEntity t WHERE t.numero = :numero")})
public class TelefonoEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="seq_telefono", sequenceName="telefonos_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="seq_telefono")  
    @Basic(optional = false)
    @Column(name = "idtelefono")
    private Integer idtelefono;
    @Size(max = 40)
    @Column(name = "numero")
    private String numero;
    @JoinColumn(name = "fk_idusuario", referencedColumnName = "idusuario")
    @ManyToOne(optional = false)
    private UsuarioEntity fkIdusuario;

    public TelefonoEntity() {
    }

    public TelefonoEntity(Integer idtelefono) {
        this.idtelefono = idtelefono;
    }

    public Integer getIdtelefono() {
        return idtelefono;
    }

    public void setIdtelefono(Integer idtelefono) {
        this.idtelefono = idtelefono;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public UsuarioEntity getFkIdusuario() {
        return fkIdusuario;
    }

    public void setFkIdusuario(UsuarioEntity fkIdusuario) {
        this.fkIdusuario = fkIdusuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtelefono != null ? idtelefono.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TelefonoEntity)) {
            return false;
        }
        TelefonoEntity other = (TelefonoEntity) object;
        if ((this.idtelefono == null && other.idtelefono != null) || (this.idtelefono != null && !this.idtelefono.equals(other.idtelefono))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.TelefonoEntitye[ idtelefono=" + idtelefono + " ]";
    }
    
}
