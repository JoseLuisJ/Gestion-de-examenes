/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "examenes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ExamenEntity.findAll", query = "SELECT e FROM ExamenEntity e"),
    @NamedQuery(name = "ExamenEntity.findByIdexamen", query = "SELECT e FROM ExamenEntity e WHERE e.idexamen = :idexamen"),
    @NamedQuery(name = "ExamenEntity.findByFechainicio", query = "SELECT e FROM ExamenEntity e WHERE e.fechainicio = :fechainicio"),
    @NamedQuery(name = "ExamenEntity.findByFechafin", query = "SELECT e FROM ExamenEntity e WHERE e.fechafin = :fechafin"),
    @NamedQuery(name = "ExamenEntity.findByIntentos", query = "SELECT e FROM ExamenEntity e WHERE e.intentos = :intentos"),
    @NamedQuery(name = "ExamenEntity.findByEstado", query = "SELECT e FROM ExamenEntity e WHERE e.estado = :estado")})
public class ExamenEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="seq_cursos", sequenceName="examenes_seq")
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="seq_cursos")
    @Basic(optional = false)
    @Column(name = "idexamen")
    private Integer idexamen;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechainicio")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechainicio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechafin")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fechafin;
    @Basic(optional = false)
    @NotNull
    @Column(name = "intentos")
    private int intentos;
    @Size(max = 1)
    @Column(name = "estado")
    private String estado;
    @JoinTable(name = "pregutas_examenes", joinColumns = {
        @JoinColumn(name = "examenes_idexamen", referencedColumnName = "idexamen")}, inverseJoinColumns = {
        @JoinColumn(name = "preguntas_idpregunta", referencedColumnName = "idpregunta")})
    @ManyToMany
    private List<PreguntaEntity> preguntaEntityeList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fkIdexamen")
    private List<PresentacionExamenEntity> presentacionExamenEntityeList;

    public ExamenEntity() {
    }

    public ExamenEntity(Integer idexamen) {
        this.idexamen = idexamen;
    }

    public ExamenEntity(Integer idexamen, Date fechainicio, Date fechafin, int intentos) {
        this.idexamen = idexamen;
        this.fechainicio = fechainicio;
        this.fechafin = fechafin;
        this.intentos = intentos;
    }

    public Integer getIdexamen() {
        return idexamen;
    }

    public void setIdexamen(Integer idexamen) {
        this.idexamen = idexamen;
    }

    public Date getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(Date fechainicio) {
        this.fechainicio = fechainicio;
    }

    public Date getFechafin() {
        return fechafin;
    }

    public void setFechafin(Date fechafin) {
        this.fechafin = fechafin;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @XmlTransient
    public List<PreguntaEntity> getPreguntaEntityeList() {
        return preguntaEntityeList;
    }

    public void setPreguntaEntityeList(List<PreguntaEntity> preguntaEntityeList) {
        this.preguntaEntityeList = preguntaEntityeList;
    }

    @XmlTransient
    public List<PresentacionExamenEntity> getPresentacionExamenEntityeList() {
        return presentacionExamenEntityeList;
    }

    public void setPresentacionExamenEntityeList(List<PresentacionExamenEntity> presentacionExamenEntityeList) {
        this.presentacionExamenEntityeList = presentacionExamenEntityeList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idexamen != null ? idexamen.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ExamenEntity)) {
            return false;
        }
        ExamenEntity other = (ExamenEntity) object;
        if ((this.idexamen == null && other.idexamen != null) || (this.idexamen != null && !this.idexamen.equals(other.idexamen))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.ExamenEntitye[ idexamen=" + idexamen + " ]";
    }
    
}
