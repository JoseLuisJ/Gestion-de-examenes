/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "usuarios")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UsuarioEntity.findAll", query = "SELECT u FROM UsuarioEntity u"),
    @NamedQuery(name = "UsuarioEntity.findByIdusuario", query = "SELECT u FROM UsuarioEntity u WHERE u.idusuario = :idusuario"),
    @NamedQuery(name = "UsuarioEntity.findByDocumento", query = "SELECT u FROM UsuarioEntity u WHERE u.documento = :documento"),
    @NamedQuery(name = "UsuarioEntity.findByPrimernombre", query = "SELECT u FROM UsuarioEntity u WHERE u.primernombre = :primernombre"),
    @NamedQuery(name = "UsuarioEntity.findBySegundonombre", query = "SELECT u FROM UsuarioEntity u WHERE u.segundonombre = :segundonombre"),
    @NamedQuery(name = "UsuarioEntity.findByApellido", query = "SELECT u FROM UsuarioEntity u WHERE u.apellido = :apellido"),
    @NamedQuery(name = "UsuarioEntity.findByCorreo", query = "SELECT u FROM UsuarioEntity u WHERE u.correo = :correo"),
    @NamedQuery(name = "UsuarioEntity.findByClave", query = "SELECT u FROM UsuarioEntity u WHERE u.clave = :clave"),
    @NamedQuery(name = "UsuarioEntity.findByEstado", query = "SELECT u FROM UsuarioEntity u WHERE u.estado = :estado"),
    @NamedQuery(name = "UsuarioEntity.login", query = "SELECT u FROM UsuarioEntity u WHERE u.correo = :correo AND u.clave = :clave")})
public class UsuarioEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="seq_usuario", sequenceName="usuarios_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator= "seq_usuario")  
    @Basic(optional = false)
    @Column(name = "idusuario")
    private Integer idusuario;
    @Basic(optional = false)
    @NotNull
    @Column(name = "documento")
    private Long documento;
    @Basic(optional = false)
    @NotNull
    
    @Column(name = "primernombre")
    private String primernombre;
    @Basic(optional = false)
    @NotNull
    @Size( max = 40)
    @Column(name = "segundonombre")
    private String segundonombre;
    @Basic(optional = false)
    @NotNull
    @Size( max = 40)
    @Column(name = "apellido")
    private String apellido;
    @Basic(optional = false)
    @NotNull
    @Size( max = 60)
    @Column(name = "correo")
    private String correo;
    @Basic(optional = false)
    @NotNull
    @Size( max = 70)
    @Column(name = "clave")
    private String clave;
    @Basic(optional = false)
    @NotNull
    @Size( max =300)
    @Column(name = "estado")
    private String estado;
    @ManyToMany(mappedBy = "usuarioEntityeList")
    private List<CursoEntity> cursoEntityeList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fkIdusuario")
    private List<PresentacionExamenEntity> presentacionExamenEntityeList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fkIdusuario")
    private List<TelefonoEntity> telefonoEntityeList;
    @JoinColumn(name = "fk_idrol", referencedColumnName = "idrol")
    @ManyToOne(optional = false)
    private RolEntity fkIdrol;

    public UsuarioEntity() {
    }

    public UsuarioEntity(Integer idusuario) {
        this.idusuario = idusuario;
    }

    public UsuarioEntity(Integer idusuario, Long documento, String primernombre, String segundonombre, String apellido, String correo, String clave, String estado) {
        this.idusuario = idusuario;
        this.documento = documento;
        this.primernombre = primernombre;
        this.segundonombre = segundonombre;
        this.apellido = apellido;
        this.correo = correo;
        this.clave = clave;
        this.estado = estado;
    }

    public Integer getIdusuario() {
        return idusuario;
    }

    public void setIdusuario(Integer idusuario) {
        this.idusuario = idusuario;
    }

    public Long getDocumento() {
        return documento;
    }

    public void setDocumento(long documento) {
        this.documento = documento;
    }

    public String getPrimernombre() {
        return primernombre;
    }

    public void setPrimernombre(String primernombre) {
        this.primernombre = primernombre;
    }

    public String getSegundonombre() {
        return segundonombre;
    }

    public void setSegundonombre(String segundonombre) {
        this.segundonombre = segundonombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @XmlTransient
    public List<CursoEntity> getCursoEntityeList() {
        return cursoEntityeList;
    }

    public void setCursoEntityeList(List<CursoEntity> cursoEntityeList) {
        this.cursoEntityeList = cursoEntityeList;
    }

    @XmlTransient
    public List<PresentacionExamenEntity> getPresentacionExamenEntityeList() {
        return presentacionExamenEntityeList;
    }

    public void setPresentacionExamenEntityeList(List<PresentacionExamenEntity> presentacionExamenEntityeList) {
        this.presentacionExamenEntityeList = presentacionExamenEntityeList;
    }

    @XmlTransient
    public List<TelefonoEntity> getTelefonoEntityeList() {
        return telefonoEntityeList;
    }

    public void setTelefonoEntityeList(List<TelefonoEntity> telefonoEntityeList) {
        this.telefonoEntityeList = telefonoEntityeList;
    }

    public RolEntity getFkIdrol() {
        return fkIdrol;
    }

    public void setFkIdrol(RolEntity fkIdrol) {
        this.fkIdrol = fkIdrol;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idusuario != null ? idusuario.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UsuarioEntity)) {
            return false;
        }
        UsuarioEntity other = (UsuarioEntity) object;
        if ((this.idusuario == null && other.idusuario != null) || (this.idusuario != null && !this.idusuario.equals(other.idusuario))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.UsuarioEntitye[ idusuario=" + idusuario + " ]";
    }
    
}
