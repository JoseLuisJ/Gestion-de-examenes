/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "roles")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "RolEntity.findAll", query = "SELECT r FROM RolEntity r"),
    @NamedQuery(name = "RolEntity.findByIdrol", query = "SELECT r FROM RolEntity r WHERE r.idrol = :idrol"),
    @NamedQuery(name = "RolEntity.findByNombre", query = "SELECT r FROM RolEntity r WHERE r.nombre = :nombre"),
    @NamedQuery(name = "RolEntity.findByEstado", query = "SELECT r FROM RolEntity r WHERE r.estado = :estado")})
  //  @NamedQuery(name = "RolEntity.SelectRol", query = "SELECT r FROM RolEntity r WHERE r.nombre= :nombre")})

public class RolEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="seq_rol", sequenceName="roles_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="seq_rol")  
    @Basic(optional = false)
    @Column(name = "idrol")
    private Integer idrol;
    @Basic(optional = false)
    @NotNull
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Size( max = 45)
    @Column(name = "estado")
    private String estado;
    @ManyToMany(mappedBy = "rolEntityeList")
    private List<PermisoEntity> permisoEntityeList;
    @OneToMany( cascade = CascadeType.ALL, mappedBy = "fkIdrol")
    private List<UsuarioEntity> usuarioEntityeList;

    public RolEntity() {
    }

    public RolEntity(Integer idrol) {
        this.idrol = idrol;
    }

    public RolEntity(Integer idrol, String nombre, String estado) {
        this.idrol = idrol;
        this.nombre = nombre;
        this.estado = estado;
    }

    public Integer getIdrol() {
        return idrol;
    }

    public void setIdrol(Integer idrol) {
        this.idrol = idrol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @XmlTransient
    public List<PermisoEntity> getPermisoEntityeList() {
        return permisoEntityeList;
    }

    public void setPermisoEntityeList(List<PermisoEntity> permisoEntityeList) {
        this.permisoEntityeList = permisoEntityeList;
    }

    @XmlTransient
    public List<UsuarioEntity> getUsuarioEntityeList() {
        return usuarioEntityeList;
    }

    public void setUsuarioEntityeList(List<UsuarioEntity> usuarioEntityeList) {
        this.usuarioEntityeList = usuarioEntityeList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idrol != null ? idrol.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof RolEntity)) {
            return false;
        }
        RolEntity other = (RolEntity) object;
        if ((this.idrol == null && other.idrol != null) || (this.idrol != null && !this.idrol.equals(other.idrol))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return nombre;
    }
    
}
