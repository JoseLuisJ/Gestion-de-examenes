/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "cursos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CursoEntity.findAll", query = "SELECT c FROM CursoEntity c"),
    @NamedQuery(name = "CursoEntity.findByIdcurso", query = "SELECT c FROM CursoEntity c WHERE c.idcurso = :idcurso"),
    @NamedQuery(name = "CursoEntity.findByNombrecurso", query = "SELECT c FROM CursoEntity c WHERE c.nombrecurso = :nombrecurso"),
    @NamedQuery(name = "CursoEntity.findByDescripcion", query = "SELECT c FROM CursoEntity c WHERE c.descripcion = :descripcion"),
    @NamedQuery(name = "CursoEntity.findByEstado", query = "SELECT c FROM CursoEntity c WHERE c.estado = :estado"),
    @NamedQuery(name = "CursoEntity.findByEspecialidad", query = "SELECT c FROM CursoEntity c WHERE c.especialidad = :especialidad")})
public class CursoEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name="entA", sequenceName="cursos_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="entA")
    @Basic(optional = false)
    @Column(name = "idcurso")
    private Integer idcurso;
    @Basic(optional = false)
    @NotNull
 
    @Column(name = "nombrecurso")
    private String nombrecurso;
    @Size(max = 60)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Size( max = 300)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 1)
    @Column(name = "especialidad")
    private String especialidad;
    @JoinTable(name = "cursos_usuarios", joinColumns = {
        @JoinColumn(name = "cursos_idcurso", referencedColumnName = "idcurso")}, inverseJoinColumns = {
        @JoinColumn(name = "usuarios_idusuario", referencedColumnName = "idusuario")})
    @ManyToMany
    private List<UsuarioEntity> usuarioEntityeList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "fkIdcurso")
    private List<PreguntaEntity> preguntaEntityeList;

    public CursoEntity() {
    }

    public CursoEntity(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public CursoEntity(Integer idcurso, String nombrecurso, String estado, String especialidad) {
        this.idcurso = idcurso;
        this.nombrecurso = nombrecurso;
        this.estado = estado;
        this.especialidad = especialidad;
    }

    public Integer getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public String getNombrecurso() {
        return nombrecurso;
    }

    public void setNombrecurso(String nombrecurso) {
        this.nombrecurso = nombrecurso;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    @XmlTransient
    public List<UsuarioEntity> getUsuarioEntityeList() {
        return usuarioEntityeList;
    }

    public void setUsuarioEntityeList(List<UsuarioEntity> usuarioEntityeList) {
        this.usuarioEntityeList = usuarioEntityeList;
    }

    @XmlTransient
    public List<PreguntaEntity> getPreguntaEntityeList() {
        return preguntaEntityeList;
    }

    public void setPreguntaEntityeList(List<PreguntaEntity> preguntaEntityeList) {
        this.preguntaEntityeList = preguntaEntityeList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcurso != null ? idcurso.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CursoEntity)) {
            return false;
        }
        CursoEntity other = (CursoEntity) object;
        if ((this.idcurso == null && other.idcurso != null) || (this.idcurso != null && !this.idcurso.equals(other.idcurso))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.CursoEntitye[ idcurso=" + idcurso + " ]";
    }
    
}
