/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "posibles_respuestas")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PosiblesRespuestaEntity.findAll", query = "SELECT p FROM PosiblesRespuestaEntity p"),
    @NamedQuery(name = "PosiblesRespuestaEntity.findByIdnorespuesta", query = "SELECT p FROM PosiblesRespuestaEntity p WHERE p.idnorespuesta = :idnorespuesta"),
    @NamedQuery(name = "PosiblesRespuestaEntity.findByEnunciado", query = "SELECT p FROM PosiblesRespuestaEntity p WHERE p.enunciado = :enunciado"),
    @NamedQuery(name = "PosiblesRespuestaEntity.findByRespuestacorrecta", query = "SELECT p FROM PosiblesRespuestaEntity p WHERE p.respuestacorrecta = :respuestacorrecta")})
public class PosiblesRespuestaEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    
    @SequenceGenerator(name="seq_posibles", sequenceName="posibles_respuestas_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="seq_posibles")        
   
    @Basic(optional = false)
    @Column(name = "idnorespuesta")
    private Integer idnorespuesta;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "enunciado")
    private String enunciado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "respuestacorrecta")
    private boolean respuestacorrecta;
    @JoinColumn(name = "fk_idpregunta", referencedColumnName = "idpregunta")
    @ManyToOne(optional = false)
    private PreguntaEntity fkIdpregunta;

    public PosiblesRespuestaEntity() {
    }

    public PosiblesRespuestaEntity(Integer idnorespuesta) {
        this.idnorespuesta = idnorespuesta;
    }

    public PosiblesRespuestaEntity(Integer idnorespuesta, String enunciado, boolean respuestacorrecta) {
        this.idnorespuesta = idnorespuesta;
        this.enunciado = enunciado;
        this.respuestacorrecta = respuestacorrecta;
    }

    public Integer getIdnorespuesta() {
        return idnorespuesta;
    }

    public void setIdnorespuesta(Integer idnorespuesta) {
        this.idnorespuesta = idnorespuesta;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public boolean getRespuestacorrecta() {
        return respuestacorrecta;
    }

    public void setRespuestacorrecta(boolean respuestacorrecta) {
        this.respuestacorrecta = respuestacorrecta;
    }

    public PreguntaEntity getFkIdpregunta() {
        return fkIdpregunta;
    }

    public void setFkIdpregunta(PreguntaEntity fkIdpregunta) {
        this.fkIdpregunta = fkIdpregunta;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idnorespuesta != null ? idnorespuesta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PosiblesRespuestaEntity)) {
            return false;
        }
        PosiblesRespuestaEntity other = (PosiblesRespuestaEntity) object;
        if ((this.idnorespuesta == null && other.idnorespuesta != null) || (this.idnorespuesta != null && !this.idnorespuesta.equals(other.idnorespuesta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.PosiblesRespuestaEntitye[ idnorespuesta=" + idnorespuesta + " ]";
    }
    
}
