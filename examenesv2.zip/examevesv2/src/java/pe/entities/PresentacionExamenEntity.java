/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author usuario
 */
@Entity
@Table(name = "presentacion_examenes")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PresentacionExamenEntity.findAll", query = "SELECT p FROM PresentacionExamenEntity p"),
    @NamedQuery(name = "PresentacionExamenEntity.findByNota", query = "SELECT p FROM PresentacionExamenEntity p WHERE p.nota = :nota"),
    @NamedQuery(name = "PresentacionExamenEntity.findByIdExamenpre", query = "SELECT p FROM PresentacionExamenEntity p WHERE p.idExamenpre = :idExamenpre")})
public class PresentacionExamenEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Column(name = "nota")
    private Integer nota;
    @Id
    @SequenceGenerator(name="seq_presenta", sequenceName="presentacion_examenes_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE,generator="seq_presenta")  
    @Basic(optional = false)
    @Column(name = "id_examenpre")
    private Integer idExamenpre;
    @JoinColumn(name = "fk_idexamen", referencedColumnName = "idexamen")
    @ManyToOne(optional = false)
    private ExamenEntity fkIdexamen;
    @JoinColumn(name = "fk_idusuario", referencedColumnName = "idusuario")
    @ManyToOne(optional = false)
    private UsuarioEntity fkIdusuario;

    public PresentacionExamenEntity() {
    }

    public PresentacionExamenEntity(Integer idExamenpre) {
        this.idExamenpre = idExamenpre;
    }

    public Integer getNota() {
        return nota;
    }

    public void setNota(Integer nota) {
        this.nota = nota;
    }

    public Integer getIdExamenpre() {
        return idExamenpre;
    }

    public void setIdExamenpre(Integer idExamenpre) {
        this.idExamenpre = idExamenpre;
    }

    public ExamenEntity getFkIdexamen() {
        return fkIdexamen;
    }

    public void setFkIdexamen(ExamenEntity fkIdexamen) {
        this.fkIdexamen = fkIdexamen;
    }

    public UsuarioEntity getFkIdusuario() {
        return fkIdusuario;
    }

    public void setFkIdusuario(UsuarioEntity fkIdusuario) {
        this.fkIdusuario = fkIdusuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idExamenpre != null ? idExamenpre.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PresentacionExamenEntity)) {
            return false;
        }
        PresentacionExamenEntity other = (PresentacionExamenEntity) object;
        if ((this.idExamenpre == null && other.idExamenpre != null) || (this.idExamenpre != null && !this.idExamenpre.equals(other.idExamenpre))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.proyectoexamenesv1.entities.PresentacionExamenEntitye[ idExamenpre=" + idExamenpre + " ]";
    }
    
}
