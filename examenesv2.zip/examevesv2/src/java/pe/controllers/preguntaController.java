/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import pe.entities.CursoEntity;
import pe.entities.PreguntaEntity;
import pe.entities.UsuarioEntity;
import pe.facades.PreguntaEntityeFacade;

/**
 *
 * @author usuario
 */
@Named(value = "preguntaController")
@ViewScoped
public class preguntaController {

    @EJB
    private PreguntaEntityeFacade pef;
    
    private PreguntaEntity pe;
    
    private PreguntaEntity pregunta;
    
   private List<PreguntaEntity>preguntas;
  
   private String enunciado;
   
   private CursoEntity cursosp;
   
    @PostConstruct    
    public void init(){

    pe= new PreguntaEntity();
    preguntas=preguntasUser();
    
    }

    public CursoEntity getCursosp() {
        return cursosp;
    }

    public void setCursosp(CursoEntity cursosp) {
        this.cursosp = cursosp;
    }


   public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }
    
    

    public PreguntaEntityeFacade getPef() {
        return pef;
    }

    public void setPef(PreguntaEntityeFacade pef) {
        this.pef = pef;
    }

    public PreguntaEntity getPe() {
        return pe;
    }

    public void setPe(PreguntaEntity pe) {
        this.pe = pe;
    }

    public PreguntaEntity getPregunta() {
        return pregunta;
    }

    public void setPregunta(PreguntaEntity pregunta) {
        this.pregunta = pregunta;
    }

    public List<PreguntaEntity> getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(List<PreguntaEntity> preguntas) {
        this.preguntas = preguntas;
    }
    
    
    
    public void registrarpregunta(){

        try {
            pe.setEstado("a");
           pef.create(pe);
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "the question has been created"));
        } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","excepcion  "+ e));
        }
    }
    
    public List<PreguntaEntity>preguntasUser(){
    FacesContext context= FacesContext.getCurrentInstance();
    UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
    List<PreguntaEntity> Preguntas = null;  
    Integer idUser;
    idUser= user.getIdusuario();
 
        try {
            
            Preguntas= new ArrayList();
            
            Preguntas= pef.preguntas(idUser);
            
            
            
            
        } catch (Exception e) {
            
               FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud "+ e));
      
        }
    return Preguntas;
    
}
    
  public void asignarPregunta(PreguntaEntity pre){
  
      pregunta=pre;
      
  }
  
  
  public void inactivarPregunta(PreguntaEntity pre){
  
      try {
      pre.setEstado("i");
      pef.edit(pre);
       FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Update","The question has been inactivated"));
      
      } catch (Exception e) {
       FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud "+ e));
      }

  
  }
  
   public void activarPregunta(PreguntaEntity pre){
  
      try {
      pre.setEstado("a");
      pef.edit(pre);
       FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Update","The question has been activated"));
      
      } catch (Exception e) {
       FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud "+ e));
      }
      
     }
   
   public void modificarEnunciado(){
   
       
       try {
           
           if (pregunta !=null) {
           
           pregunta.setEnunciado(enunciado);
           pef.edit(pregunta);
           
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Update","the Wording has been Updated"));
           }
           
       } catch (Exception e) {
       
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud "+ e));
       
       }
   }
       public void modificarCurso(){
       
        try {
           
           if (pregunta !=null) {
           
           pregunta.setFkIdcurso(cursosp);
           pef.edit(pregunta);
           
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Update","the Course of question "+pregunta.getEnunciado()+  " has been Updated"));
           }
           
       } catch (Exception e) {
       
           FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud "+ e));
       
       }
       
       }
   
   

/*  public PreguntaEntity AsignarPregunta2(PreguntaEntity pre){
  
      PreguntaEntity pregunta2;
      if (pre !=null) {
          pregunta2=pre;
      }
  
  return pre;
  }

  
/* public List<PreguntaEntity>preguntasUser(){
 FacesContext context= FacesContext.getCurrentInstance();
 UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
 List<PreguntaEntity> Preguntas;  
 Integer idUser;
 if (user != null) {
        idUser= user.getIdusuario();
         
     }
  
         Preguntas=new ArrayList();
         Preguntas= pef.findAll();
         
         if (!Preguntas.isEmpty()) {
        
             for (int i = 0; i < Preguntas.size(); i++) {
                 {
                     
                 }
             }
        }
         
         
         
         
         
   
 
 
 }*/
         
         
    public PreguntaEntity getPregunta (java.lang.Integer id) {
        return pef.find(id);
    }

    @FacesConverter(forClass = PreguntaEntity.class, value = "p")
    public static class PreguntasControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            preguntaController controller = (preguntaController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "preguntaController");
            return controller.getPregunta(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof PreguntaEntity) {
                PreguntaEntity o = (PreguntaEntity) object;
                return getStringKey(o.getIdpregunta());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + PreguntaEntity.class.getName());
            }
        }

    }


    }

    


