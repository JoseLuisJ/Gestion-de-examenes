/*¿+
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import pe.entities.CursoEntity;
import pe.facades.CursoEntityeFacade;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;


import javax.faces.component.UIComponent;

import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.view.ViewScoped;
import org.primefaces.component.datatable.DataTable;
import org.primefaces.context.RequestContext;
import org.primefaces.event.CellEditEvent;
import org.primefaces.event.RowEditEvent;
import org.primefaces.event.SelectEvent;
import pe.entities.UsuarioEntity;


/**
 *
 * @author usuario
 */
@Named(value = "cursocontrolador")
@ViewScoped

 //  @PostConstruct() cuando se necesiten una listas al principio
public class CursoController implements Serializable{

    @EJB // inicializar el objecto PARTE DEL MODDELO 
    private CursoEntityeFacade cef;
    private CursoEntity ce;

    private String nombreCurso;
   
    private String descripsion;
    
    private String especialidad;
    
    private List<UsuarioEntity>usuarios= new ArrayList();
    
    private String estado;

    private CursoEntity cu;
    
    private List <CursoEntity> cursos;
    
    @PostConstruct
    public void init() {
    ce=new CursoEntity();
    cursos=listarCourses();
    
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public List<UsuarioEntity> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<UsuarioEntity> usuarios) {
        this.usuarios = usuarios;
    }

    public CursoEntity getCe() {
        return ce;
    }

    public void setCe(CursoEntity ce) {
        this.ce = ce;
    }

    public CursoEntityeFacade getCef() {
        return cef;
    }

    public void setCef(CursoEntityeFacade cef) {
        this.cef = cef;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }



    public String getDescripsion() {
        return descripsion;
    }

    public void setDescripsion(String descripsion) {
        this.descripsion = descripsion;
    }

    public CursoEntity getCu() {
        return cu;
    }

    public void setCu(CursoEntity cu) {
        this.cu = cu;
    }

    
   

    
   public String registrarCurso(){
       String url;
       try {
     FacesContext context =FacesContext.getCurrentInstance();
     UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
            if (user != null) {
                usuarios.add(user);
            }
            
        ce.setUsuarioEntityeList(usuarios);
        ce.setEstado("a");
        cef.create(ce);
        FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro","el curso se ha creado correctamente"));
        
       url= "registroCursos?faces-redirect=true";
       } catch (Exception e) {
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud"));
        url= null;
        }
       return url;
    }

   
   public List<CursoEntity>listarCourses(){
   
FacesContext context= FacesContext.getCurrentInstance();
UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
List<CursoEntity> cursos= new ArrayList();
List<CursoEntity> cursos2= new ArrayList();
       if (user != null) {
           Integer id= user.getIdusuario();
         cursos= cef.verCursosusu(id);
           if (!cursos.isEmpty()) {
              cursos2=cursos;
           }else{
           cursos2=null;
           }
       }else{
       FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud la lista esta vacia"));
       }
    return cursos2;
   }
   
   
   
  
   
   public void DeleteCourse(CursoEntity cu){
    

        
        try {
           
        cef.remove(cu);
       } catch (Exception e) {
       FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Eliminacion", "existe el error " +e));
       }
   }
    
 
   public void referencia (CursoEntity curso){
   
   cu= curso;
   
   }
   
   public void validacion(){
       
       if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
                  cu.setNombrecurso(nombreCurso);
                  cef.edit(cu);
                  
                   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The name "+cu.getNombrecurso() +" It has been updated"));
           } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           }
        
       }
   
   }
   
   public void cambiarDescripcion(){
   
      if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
                  cu.setDescripcion(descripsion);
                  cef.edit(cu);
                  
                   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The description it has been updated"));
           } catch (Exception e) {  
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           
           }
        
       }
       
   }
   
   
      public void cambiarEspecialidad(){
   
      if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
                  cu.setEspecialidad(especialidad);
                  cef.edit(cu);
                  
                   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The specialty has been updated"));
           } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           }
        
       }
       
   }
      
      public void cambiarEstado(){
   
      if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
                  cu.setEstado(estado);
                  cef.edit(cu);
                  
                   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The state it has been updated"));
           } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           }
        
       }
       
   }   
      
      
    public void cambiarEstudiantes(){
   
      if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
               
                  cu.setUsuarioEntityeList(usuarios);
                  cef.edit(cu);
                  
                   FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The students it has been updated"));
           } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           }
        
       }
       
   }   



      
    public void cambiarCurso(){
   
       Boolean creacioncurso= false;    
      FacesContext context =FacesContext.getCurrentInstance();
      RequestContext context2 = RequestContext.getCurrentInstance();  
      if (cu==null) {
           
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error objecto vacio"));
       }else {
           try {
        
             
               UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
            if (user != null) {
               usuarios.add(user);
               cu.setNombrecurso(nombreCurso);
               cu.setDescripcion(descripsion);
               cu.setEspecialidad(especialidad);
               cu.setEstado(estado);
               cu.setUsuarioEntityeList(usuarios);
               cef.edit(cu);
               creacioncurso= true;
                  
             FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Confirmation", "The Course has been update"));
            }else{
             FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","valide la sesion"));
             creacioncurso= false;
            }
              
           } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", ""+e));
           creacioncurso= false;
           }
        
       }
    
        context2.addCallbackParam("ok",creacioncurso); 
        
   }           
      
    
  /*  public List<UsuarioEntity> usuariosCurso(){
    
       UsuarioEntity usu; 
     List <UsuarioEntity> lista= new ArrayList();
        List <UsuarioEntity> listaUser2= new ArrayList();
    lista= cef.verUsuarios();
        if ( lista.isEmpty()) {
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","lsita vacia"));
        }
        
        for (int i = 0; i < lista.size(); i++) {
            if (lista.get(i).getFkIdrol().getIdrol()==9 && lista.get(i).getEstado().equalsIgnoreCase("a")) {
            
                usu= lista.get(i);
                listaUser2.add(usu);
            
            
            }
        }
        return listaUser2;
    }
         
      
  
   
   
/* public CursoEntity ActualizarCurso( ){
      CursoEntity cur = null;
     try {
         DataTable table= new DataTable(); 
         if (table.getRowData() instanceof CursoEntity){

           cur = (CursoEntity) table.getRowData();
         }
         
  
 
     } catch (Exception e) {
     FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "existe el error " +e));
     }
     return cur;

 }
 
 public String verCurso(){
 CursoEntity curso=ActualizarCurso();
 return curso.getNombrecurso();
 
 }  
 
  
   

  
  /* public void actulizarcurso( CellEditEvent event){
       try {
     
   String vaLorNuevo = (String) event.getNewValue();
   String ValorViego = (String) event.getOldValue();
   
     if(vaLorNuevo != null && !vaLorNuevo.equals(ValorViego)) {

        DataTable table = (DataTable) event.getSource();
        if (table.getRowData() instanceof CursoEntity){

            CursoEntity cur = (CursoEntity) table.getRowData();
            cu.setNombrecurso(vaLorNuevo);
            cef.edit(cu);

        }
     
     }else{
        
         DataTable table = (DataTable) event.getSource();
         CursoEntity cursoanterior = (CursoEntity) table.getRowData();
            cef.edit(cu);
        
     
     }

            } catch (Exception e) {
           FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "actualizacion", "existe el error " +e));
       }
       
   }
   
   
    /*public void actualizarLista(CellEditEvent event){
 
     Object oldValue = event.getOldValue();
    Object newValue = event.getNewValue();

    if(newValue != null && !newValue.equals(oldValue)) {

        DataTable table = (DataTable) event.getSource();
        if (table.getRowData() instanceof CursoEntity){

            CursoEntity cursoNuevo = (CursoEntity) table.getRowData();
            cef.edit(cu);

        }else{
            CursoEntity cursoanterior = (CursoEntity) table.getRowData();
            cef.edit(cu);
        }

        FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, "Ubicacion cambiada", "Anterior: " + oldValue + ", Nuevo:" + newValue);
        FacesContext.getCurrentInstance().addMessage(null, msg);
     
        
        

        
 }
   }
   
   
 
   
  /* public Integer IntegerKey(Integer idC){
   Integer id= idC;
   return id;
  }*/
   
   /* public String NameCourse(Integer id) {
       CursoEntity cu= cef.find(id);
      return  cu.getNombrecurso();
      
    }*/
   
  
      
    public CursoEntity getCursosEntity(java.lang.Integer id) {
        return cef.find(id);
    }

    
     @FacesConverter(forClass = CursoEntity.class)
    public static class CursoControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            CursoController controller = (CursoController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "cursocontrolador");
            return controller.getCursosEntity(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof CursoEntity) {
                CursoEntity o = (CursoEntity) object;
                return getStringKey(o.getIdcurso());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + CursoEntity.class.getName());
            }
        }

    }

            
}
