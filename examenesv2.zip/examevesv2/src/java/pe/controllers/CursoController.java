/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;


import pe.entities.CursoEntity;
import pe.facades.CursoEntityeFacade;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;


/**
 *
 * @author usuario
 */
@Named(value = "cursocontrolador")
@RequestScoped

 //  @PostConstruct() cuando se necesiten una listas al principio
public class CursoController {

    @EJB // inicializar el objecto PARTE DEL MODDELO 
    private CursoEntityeFacade cef;
    private CursoEntity ce;
    
    @PostConstruct
    public void init() {
    ce=new CursoEntity();
    }

    
    public CursoEntity getCe() {
        return ce;
    }

    public void setCe(CursoEntity ce) {
        this.ce = ce;
    }

    public CursoEntityeFacade getCef() {
        return cef;
    }

    public void setCef(CursoEntityeFacade cef) {
        this.cef = cef;
    }
    
    
    
   public void registrarCurso(){
        try {
        ce.setEstado("a");
        cef.create(ce);
        FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro","el curso se ha creado correctamente"));
        } catch (Exception e) {
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud"));
        
        }
    }
    
    public CursoEntity getCursosEntity(java.lang.Integer id) {
        return cef.find(id);
    }

    
     @FacesConverter(forClass = CursoEntity.class)
    public static class CursoControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            CursoController controller = (CursoController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "cursocontrolador");
            return controller.getCursosEntity(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof CursoEntity) {
                CursoEntity o = (CursoEntity) object;
                return getStringKey(o.getIdcurso());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + CursoEntity.class.getName());
            }
        }

    }

            
}
