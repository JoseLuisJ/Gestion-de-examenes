/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;


import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;


import javax.faces.context.FacesContext;
import javax.faces.event.ComponentSystemEvent;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import pe.entities.UsuarioEntity;



/**
 *
 * @author usuario
 */
@Named(value = "validacion")
@SessionScoped
public class validacionSesionController implements Serializable{
    

    
    public void verificarSesion(){
    
        try {
            FacesContext context =FacesContext.getCurrentInstance();
            UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
            if (user==null) {
            context.getExternalContext().redirect("../../../index.xhtml");
            }
        } catch (Exception e) {
            
              FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "En el momento no se pudo procesar su solicitud" + " " + e));
        }
    
    }
}
