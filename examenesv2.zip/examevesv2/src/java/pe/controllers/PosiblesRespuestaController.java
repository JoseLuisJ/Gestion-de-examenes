/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;
import javax.faces.view.ViewScoped;
import org.primefaces.context.RequestContext;
import pe.entities.PosiblesRespuestaEntity;
import pe.entities.PreguntaEntity;
import pe.entities.UsuarioEntity;
import pe.facades.PosiblesRespuestaEntityeFacade;

/**
 *
 * @author usuario
 */
@Named(value = "poRtaController")
@ViewScoped
public class PosiblesRespuestaController {

    /**
     * Creates a new instance of PosiblesRespuestaController
     */
    @EJB
    private PosiblesRespuestaEntityeFacade prf;
    
    private PosiblesRespuestaEntity posiblesRespuestas1;
    private PosiblesRespuestaEntity posiblesRespuestas2;
    private PosiblesRespuestaEntity posiblesRespuestas3;
    private PosiblesRespuestaEntity posiblesRespuestas4;
    private PreguntaEntity pregunta;
    private List<PosiblesRespuestaEntity> posiblesrta;
    
   @PostConstruct
   public void init(){
   posiblesRespuestas1=new PosiblesRespuestaEntity();
   posiblesRespuestas2=new PosiblesRespuestaEntity();
   posiblesRespuestas3=new PosiblesRespuestaEntity();
   posiblesRespuestas4=new PosiblesRespuestaEntity();
   
   
   }    

    public List<PosiblesRespuestaEntity> getPosiblesrta() {
        return posiblesrta;
    }

    public void setPosiblesrta(List<PosiblesRespuestaEntity> posiblesrta) {
        this.posiblesrta = posiblesrta;
    }

   
    public PosiblesRespuestaEntityeFacade getPrf() {
        return prf;
    }

    public void setPrf(PosiblesRespuestaEntityeFacade prf) {
        this.prf = prf;
    }

    public PosiblesRespuestaEntity getPosiblesRespuestas1() {
        return posiblesRespuestas1;
    }

    public void setPosiblesRespuestas1(PosiblesRespuestaEntity posiblesRespuestas1) {
        this.posiblesRespuestas1 = posiblesRespuestas1;
    }

    public PosiblesRespuestaEntity getPosiblesRespuestas2() {
        return posiblesRespuestas2;
    }

    public void setPosiblesRespuestas2(PosiblesRespuestaEntity posiblesRespuestas2) {
        this.posiblesRespuestas2 = posiblesRespuestas2;
    }

    public PosiblesRespuestaEntity getPosiblesRespuestas3() {
        return posiblesRespuestas3;
    }

    public void setPosiblesRespuestas3(PosiblesRespuestaEntity posiblesRespuestas3) {
        this.posiblesRespuestas3 = posiblesRespuestas3;
    }

    public PosiblesRespuestaEntity getPosiblesRespuestas4() {
        return posiblesRespuestas4;
    }

    public void setPosiblesRespuestas4(PosiblesRespuestaEntity posiblesRespuestas4) {
        this.posiblesRespuestas4 = posiblesRespuestas4;
    }

    public PreguntaEntity getPregunta() {
        return pregunta;
    }

    public void setPregunta(PreguntaEntity pregunta) {
        this.pregunta = pregunta;
    }
   
    
    
    
    public void selecion(PreguntaEntity pre){
    pregunta= pre;
    
    
    /*Boolean mostrarModal;
   RequestContext context2 = RequestContext.getCurrentInstance();
   
        if (pregunta.getPosiblesRespuestaEntityeList().isEmpty()) {
            mostrarModal=false;
            
        }else{
        
        mostrarModal=true;
        
        }   
        // con este parametro vamos a invocar una funcion de script que segun true o false invocara una modal
         context2.addCallbackParam("mostrar",mostrarModal); 
    
*/
    }
    
    public Boolean desabilitarBoton( PreguntaEntity pre){
    
        PreguntaEntity pregunta2= pre;
        Boolean desabilitado;
        if (pregunta2.getPosiblesRespuestaEntityeList().isEmpty()) {
            
        desabilitado=false;
        }else{
        
        desabilitado= true;
        
        }
        
    return  desabilitado;
    }
    
    
    
    public void RegistrarCurso(PreguntaEntity pre) {
    
        try {
            posiblesRespuestas1.setFkIdpregunta(pregunta);
            prf.create(posiblesRespuestas1);
            posiblesRespuestas2.setFkIdpregunta(pregunta);
            prf.create(posiblesRespuestas2);
            posiblesRespuestas3.setFkIdpregunta(pregunta);
                prf.create(posiblesRespuestas3);
            posiblesRespuestas4.setFkIdpregunta(pregunta);
            prf.create(posiblesRespuestas4);
             FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "creation","creating the questions has been successful"));
        } catch (Exception e) {
        FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","alerta"+e));
        }
    }
    
    

    public List<PosiblesRespuestaEntity> PosiblesRespuestaUser(PosiblesRespuestaEntity po) {
        FacesContext context = FacesContext.getCurrentInstance();
        UsuarioEntity user = (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
        List<PosiblesRespuestaEntity> posiblesRespuestas = null;
        Integer idUser;
        idUser = user.getIdusuario();

        try {
            posiblesRespuestas = new ArrayList();
            posiblesRespuestas = prf.posiblesRespuestas(idUser);

            if (posiblesRespuestas == null) {

                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "information", user.getPrimernombre() + "  still have not created possible answers"));

            }

        } catch (Exception e) {

            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "En el momento no se pudo procesar su solicitud " + e));

        }

        return posiblesRespuestas;
    }
    
    
    public PosiblesRespuestaEntity getPosiblesRespuestas(java.lang.Integer id) {
        return prf.find(id);
    }
    
    
    
      
     @FacesConverter(forClass = PosiblesRespuestaEntity.class)
    public static class PosiblesRespuestasControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            PosiblesRespuestaController controller = (PosiblesRespuestaController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "poRtaController");
            return controller.getPosiblesRespuestas(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof PosiblesRespuestaEntity) {
                PosiblesRespuestaEntity o = (PosiblesRespuestaEntity) object;
                return getStringKey(o.getIdnorespuesta());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + PosiblesRespuestaEntity.class.getName());
            }
        }

    }

}
