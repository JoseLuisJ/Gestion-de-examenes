/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import pe.entities.PermisoEntity;
import pe.facades.PermisoEntityeFacade;

@Named( value = "permisoc")
@RequestScoped

public class PermisoController {
@EJB    
private PermisoEntityeFacade pef;
private PermisoEntity pe;
@PostConstruct
public void init(){
pe=new PermisoEntity();
}

    public PermisoEntityeFacade getPef() {
        return pef;
    }

    public void setPef(PermisoEntityeFacade pef) {
        this.pef = pef;
    }

    public PermisoEntity getPe() {
        return pe;
    }

    public void setPe(PermisoEntity pe) {
        this.pe = pe;
    }

public void registrarPermiso(){
    try {
        pef.create(pe);
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro","el Permiso se ha creado correctamente"));
    } catch (Exception e) {
     FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud"+" "+e));
    }

}


}
