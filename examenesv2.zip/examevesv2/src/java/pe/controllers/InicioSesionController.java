/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import com.sun.mail.handlers.message_rfc822;
import java.io.Serializable;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;

import javax.faces.application.FacesMessage;

import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import org.primefaces.context.RequestContext;
import pe.entities.UsuarioEntity;
import pe.facades.UsuarioEntityeFacade;

/**
 *
 * @author usuario
 */
@Named(value = "login")
@SessionScoped
public class InicioSesionController implements Serializable{
    @EJB
    private UsuarioEntityeFacade uef;
    private UsuarioEntity uec;

    private String Correo;
    private String clave;

@PostConstruct    
public void init(){

uec=new UsuarioEntity();
}

    public UsuarioEntityeFacade getUef() {
        return uef;
    }

    public void setUef(UsuarioEntityeFacade uef) {
        this.uef = uef;
    }

    public UsuarioEntity getUec() {
        return uec;
    }

    public void setUec(UsuarioEntity uec) {
        this.uec = uec;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

   
    
    


public String inicioSesion(){
  UsuarioEntity us;
  String redireccion = null;
  Boolean estarLogueado=false;
  FacesContext context= FacesContext.getCurrentInstance();
  RequestContext context2 = RequestContext.getCurrentInstance();  
  
      us= uef.iniciarSesion(uec.getCorreo(), uec.getClave());
        if (us != null) {
           
             // faces se utiliza con el fin de capturar el objecto que esta iniciando sesion 
            context.getExternalContext().getSessionMap().put("usuario", us);
            estarLogueado=true;
            if (us.getFkIdrol().getIdrol()==10) {
            redireccion= "app/gestionUsuarios/profesor/paginaprincipal2?faces-redirect=true";
          
            }else if(us.getFkIdrol().getIdrol()==2) {
             redireccion= "app/gestionUsuarios/administrador/paginaprincipal?faces-redirect=true";
              
            }else if(us.getFkIdrol().getIdrol()==9){
            redireccion= "app/gestionUsuarios/estudiante/paginaprincipal?faces-redirect=true";
             
            }
       
          
       }else{
            context.addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "login","Usuario y clave incorrectas"));
            estarLogueado=false;
         //redireccion="index?faces-redirect=true";
        }
        
        
      context2.addCallbackParam("estarLogueado",estarLogueado);    
  
       return redireccion;

        
}


public String nombreUser(){
FacesContext context= FacesContext.getCurrentInstance();
UsuarioEntity user= (UsuarioEntity) context.getExternalContext().getSessionMap().get("usuario");
return "Bienvenido "+user.getPrimernombre();

}

public void cerrarCesion(){

String redirecion;   
HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
session.invalidate();


 
}
}