/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;

import javax.faces.application.FacesMessage;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.faces.model.SelectItem;
import javax.inject.Named;
import pe.entities.RolEntity;
import pe.entities.UsuarioEntity;
import pe.facades.RolEntityeFacade;
import pe.facades.UsuarioEntityeFacade;

@Named(value = "usuarioC")
@RequestScoped
public class UsuarioController implements Serializable{
    
   @EJB
   private UsuarioEntityeFacade uef;
   private UsuarioEntity ue;
   private String documento;
   private List<UsuarioEntity>listaUsuarios;
    
    @PostConstruct
    public void init(){
    ue=new UsuarioEntity();
    this.listaUsuarios=mostrarUsers();
   
    }

    public List<UsuarioEntity> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(List<UsuarioEntity> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    
    

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public UsuarioEntity getUe() {
        return ue;
    }

    public void setUe(UsuarioEntity ue) {
        this.ue = ue;
    }

    public UsuarioEntityeFacade getUef() {
        return uef;
    }

    public void setUef(UsuarioEntityeFacade uef) {
        this.uef = uef;
    }
   
    
    public List<UsuarioEntity> mostrarUsers(){
    List<UsuarioEntity>listaUser= new ArrayList();
    List<UsuarioEntity>listaUser2= new ArrayList();
    UsuarioEntity usu;
    listaUser= uef.findAll();
        for (int i = 0; i < listaUser.size(); i++) {
            if (listaUser.get(i).getFkIdrol().getIdrol()==9 && listaUser.get(i).getEstado().equalsIgnoreCase("a")) {
            
                usu= listaUser.get(i);
                listaUser2.add(usu);
            
            
            }
        }
     return listaUser2;       
    }
    
    
    public void registrarUsuario(){
    
       
            
        
            ue.setDocumento(Long.parseLong(this.documento));
        
        
        
            try {
            uef.create(ue);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro", "el Usuario se ha creado correctamente"));
            } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "En el momento no se pudo procesar su solicitud" + " " + e));
           }

    }
    
    public void registarUser2(){
    
       
            
          
            ue.setDocumento(Long.parseLong(this.documento));
           RolEntity rol2= new RolEntity();
            rol2.setIdrol(9);
            ue.setFkIdrol(rol2);
            ue.setEstado("a");
        
        
            try {
            uef.create(ue);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro", "el Usuario se ha creado correctamente"));
            } catch (Exception e) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error", "En el momento no se pudo procesar su solicitud" + " " + e));
           }

        }
    
      
    
    
       public UsuarioEntity getUsuarioEntity(java.lang.Integer id) {
        return uef.find(id);
        }
    
     @FacesConverter(forClass = UsuarioEntity.class, value = "a")
    public static class UsuarioControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            UsuarioController controller = (UsuarioController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "usuarioC");
            return controller.getUsuarioEntity(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof UsuarioEntity) {
                UsuarioEntity o = (UsuarioEntity) object;
                return getStringKey(o.getIdusuario());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + UsuarioEntity.class.getName());
            }
        }

    }

}