/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;
import org.apache.jasper.tagplugins.jstl.ForEach;
import pe.entities.RolEntity;
import pe.facades.RolEntityeFacade;

@Named(value = "rolC")
@RequestScoped
public class RolController implements Serializable{
    @EJB
    private RolEntityeFacade ref;
    private RolEntity re;
    
@PostConstruct
public void init(){
re=new RolEntity();
}

    public RolEntityeFacade getRef() {
        return ref;
    }

    public void setRef(RolEntityeFacade ref) {
        this.ref = ref;
    }

    public RolEntity getRe() {
        return re;
    }

    public void setRe(RolEntity re) {
        this.re = re;
    }
  
     
public void registrarRol(){
    try {
     ref.create(re);
         FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO, "Registro","el rol  se ha creado correctamente"));
    } catch (Exception e) {
     FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_FATAL, "Error","En el momento no se pudo procesar su solicitud"+" "+e));
    }

}



      public List<RolEntity> mostrarRoles() {
      
          return ref.findAll();

     }
      

         
   public RolEntity getRolEntity(java.lang.Integer id) {
       return ref.find(id);
    }
  
 @FacesConverter(forClass = RolEntity.class)
    public static class RolControllerConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            RolController controller = (RolController) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "rolC");
            return controller.getRolEntity(getKey(value));
        }

        java.lang.Integer getKey(String value) {
            java.lang.Integer key;
            key = Integer.valueOf(value);
            return key;
        }

        String getStringKey(java.lang.Integer value) {
            StringBuilder sb = new StringBuilder();
            sb.append(value);
            return sb.toString();
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            if (object == null) {
                return null;
            }
            if (object instanceof RolEntity) {
                RolEntity o = (RolEntity) object;
                return getStringKey(o.getIdrol());
            } else {
                throw new IllegalArgumentException("object " + object + " is of type " + object.getClass().getName() + "; expected type: " + RolEntity.class.getName());
            }
        }

    }

}

