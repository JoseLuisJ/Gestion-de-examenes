/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.facades;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import pe.entities.RolEntity;
import pe.entities.UsuarioEntity;

/**
 *
 * @author usuario
 */
@Stateless
public class RolEntityeFacade extends AbstractFacade<RolEntity> {

    @PersistenceContext(unitName = "examenPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public RolEntityeFacade() {
        super(RolEntity.class);
    }
    
    public RolEntity  seleccionarRol( String nombreRol){
        
       RolEntity rol= null;

     
        try {
            
           TypedQuery<RolEntity> query = em.createNamedQuery("RolEntity.findByNombre", RolEntity.class);
            query.setParameter("nombre", nombreRol);
            List<RolEntity>listaR= new ArrayList();
            listaR= query.getResultList();
             
              
           if(!listaR.isEmpty()){
           rol =listaR.get(0);
            }
        } catch (Exception e) {
         
           
        e.printStackTrace();
        }   
        
        return rol;
    
        }
    
  
}
