/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.facades;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import pe.entities.CursoEntity;
import pe.entities.UsuarioEntity;

/**
 *
 * @author usuario
 */
@Stateless
public class CursoEntityeFacade extends AbstractFacade<CursoEntity> {

    @PersistenceContext(unitName = "examenPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CursoEntityeFacade() {
        super(CursoEntity.class);
    }
    
    public List<UsuarioEntity> verUsuarios( Integer id){
        

        List<UsuarioEntity >usuarios;
     Query query = em.createQuery("SELECT u FROM UsuarioEntity u JOIN  u.cursoEntityeList cu WHERE cu.idcurso= ?1");
    query.setParameter(1, id);
     List<UsuarioEntity> users= new ArrayList();
    users= query.getResultList();
        if (!users.isEmpty()) {
            usuarios= users;
            
        }else{
         
            usuarios= null;
            
            
        }
      
   
   return usuarios;
   
    }
    
      
    public List<CursoEntity> verCursosusu( Integer id){
        

      List<CursoEntity >Cursos;
        List<CursoEntity >Cursos2;
     Query query = em.createQuery("SELECT c FROM CursoEntity c JOIN  c.usuarioEntityeList us WHERE us.idusuario= ?1");
     query.setParameter(1, id);
     
    Cursos= query.getResultList();
        if (!Cursos.isEmpty()) {
            Cursos2=Cursos;
            
        }else{
         
            Cursos2= null;
            
            
        }
      
   
   return Cursos2;
   
    }
    
}