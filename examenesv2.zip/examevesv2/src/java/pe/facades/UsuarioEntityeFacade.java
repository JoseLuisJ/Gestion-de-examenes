/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.facades;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import pe.entities.RolEntity;
import pe.entities.UsuarioEntity;

/**
 *
 * @author usuario
 */
@Stateless
public class UsuarioEntityeFacade extends AbstractFacade<UsuarioEntity> {

    @PersistenceContext(unitName = "examenPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UsuarioEntityeFacade() {
        super(UsuarioEntity.class);
    }
    

    
    
    public UsuarioEntity iniciarSesion(String correo, String clave) {
        
        UsuarioEntity us= null;
        try {
            TypedQuery<UsuarioEntity> query = em.createNamedQuery("UsuarioEntity.login", UsuarioEntity.class);
            query.setParameter("correo", correo);
            query.setParameter("clave", clave);
           List<UsuarioEntity>listaU= new ArrayList();
           listaU= query.getResultList();
              
           if(!listaU.isEmpty()){
            us=listaU.get(0);
            }
        } catch (Exception e) {
         
        e.printStackTrace();
        }   
return us;
    }

}    
     

    /*public UsuarioEntity login(String correo, String clave){
        try {
            TypedQuery<UsuarioEntity> query = em.createNamedQuery("UsuarioEntity.login", UsuarioEntity.class);
            query.setParameter("correo", correo);
            query.setParameter("clave", clave);
            return query.getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }*/
    

