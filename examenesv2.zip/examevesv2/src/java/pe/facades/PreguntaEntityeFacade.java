/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.facades;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import pe.entities.PreguntaEntity;
import pe.entities.UsuarioEntity;

/**
 *
 * @author usuario
 */
@Stateless
public class PreguntaEntityeFacade extends AbstractFacade<PreguntaEntity> {

    @PersistenceContext(unitName = "examenPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PreguntaEntityeFacade() {
        super(PreguntaEntity.class);
    }
 public List<PreguntaEntity> preguntas(Integer id){
    List<PreguntaEntity >preguntas;
    List<PreguntaEntity> Preguntas2= new ArrayList();
     try {
         
     Query query = em.createQuery("SELECT p FROM PreguntaEntity p JOIN  p.fkIdcurso cu JOIN  cu.usuarioEntityeList us WHERE us.idusuario= ?1");
     query.setParameter(1, id);
     preguntas= query.getResultList();
        if (!preguntas.isEmpty()) {
            Preguntas2=preguntas ;
            
        }else{
         
            Preguntas2= null;
            
            
        }
         
     } catch (Exception e) {
     
         e.printStackTrace();
     }
 
   
      
   
   return  Preguntas2;
 
 }  
}
