/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.facades;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import pe.entities.PosiblesRespuestaEntity;
import pe.entities.PreguntaEntity;

/**
 *
 * @author usuario
 */
@Stateless
public class PosiblesRespuestaEntityeFacade extends AbstractFacade<PosiblesRespuestaEntity> {

    @PersistenceContext(unitName = "examenPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PosiblesRespuestaEntityeFacade() {
        super(PosiblesRespuestaEntity.class);
    }
    
    
    public List<PosiblesRespuestaEntity> posiblesRespuestas(Integer id){
    List<PosiblesRespuestaEntity > posiblesR1;
    List<PosiblesRespuestaEntity> posiblesR2= new ArrayList();
     try {
         
     Query query = em.createQuery("SELECT po FROM  PosiblesRespuestaEntity po JOIN  po.fkIdpregunta p JOIN  p.fkIdcurso cu JOIN cu.usuarioEntityeList us WHERE us.idusuario= ?1");
     query.setParameter(1, id);
     posiblesR1= query.getResultList();
        if (!posiblesR1.isEmpty()) {
            posiblesR2=posiblesR1 ;
            
        }else{
         
            posiblesR2= null;
            
            
        }
         
     } catch (Exception e) {
     
         e.printStackTrace();
     }
 
   
      
   
   return  posiblesR2;
 
 }  
}
