/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpruebas;

import pe.entities.RolEntity;
import pe.entities.UsuarioEntity;
import pe.facades.RolEntityeFacade;
import pe.facades.UsuarioEntityeFacade;

/**
 *
 * @author usuario
 */
public class claseP {
    
    public static void main(String[] args) {
        UsuarioEntity ue;
        RolEntity rol= new RolEntity();
        UsuarioEntityeFacade uef;
        RolEntityeFacade ref= new RolEntityeFacade();
        String Nombre= "administrador";
        rol.setNombre(Nombre);
            
        
     //   rol=ref.seleccionarRol2();
        System.out.println(rol.getIdrol());
        
        
    }
}
